import SplashScreen from "./splashScreen";
import RegisterScreen from "./registerScreen";
import LoginScreen from './loginScreen';
import MainScreen from './mainScreen';

export {SplashScreen, RegisterScreen, LoginScreen, MainScreen};
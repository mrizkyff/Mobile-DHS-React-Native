import SplashScreen from "./splashScreen";
import RegisterScreen from "./registerScreen";
import LoginScreen from './loginScreen';
import MainScreen from './mainScreen';
import ShoppingScreen from './shoppingScreen';

export {SplashScreen, RegisterScreen, LoginScreen, MainScreen, ShoppingScreen};